/* ==========================================================================
   AYOVA THEME INTERACTION & DRAWER LOGIC
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  // Mobile Menu Toggle
  const mobileToggle = document.querySelector('[data-mobile-menu-toggle]');
  const mobileMenu = document.querySelector('[data-mobile-menu]');
  if (mobileToggle && mobileMenu) {
    mobileToggle.addEventListener('click', () => {
      mobileMenu.classList.toggle('active');
    });
  }

  // Quick Add to Cart Simulation
  document.querySelectorAll('[data-add-to-cart]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const originalText = btn.innerText;
      btn.innerText = 'Added ✓';
      btn.classList.add('btn-added');

      // Update Cart Count Badge
      const cartBadges = document.querySelectorAll('[data-cart-count]');
      cartBadges.forEach(badge => {
        const count = parseInt(badge.innerText || '0', 10) + 1;
        badge.innerText = count;
      });

      setTimeout(() => {
        btn.innerText = originalText;
        btn.classList.remove('btn-added');
      }, 1800);
    });
  });
});
